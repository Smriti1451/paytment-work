// ─────────────────────────────────────────────────────────────
//  server.js  –  Razorpay + Express payment gateway backend
// ─────────────────────────────────────────────────────────────

require("dotenv").config();
const express = require("express");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ─────────────────────────────────────────────────
app.use(cors({ origin: process.env.FRONTEND_URL || "*" }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

// ── Razorpay instance ──────────────────────────────────────────
const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET,
});

// ── In-memory order store (replace with a DB in production) ───
const orders = {};

// ─────────────────────────────────────────────────────────────
//  ROUTE 1: Create Order
//  Called by frontend before showing the Razorpay popup.
//  Returns an order_id that the frontend passes to Razorpay.
// ─────────────────────────────────────────────────────────────
app.post("/api/create-order", async (req, res) => {
  try {
    const { amount, currency = "INR", receipt, notes = {} } = req.body;

    // Validate
    if (!amount || isNaN(amount) || amount <= 0) {
      return res.status(400).json({ error: "Invalid amount" });
    }

    const options = {
      amount: Math.round(amount * 100), // Razorpay expects paise (1 INR = 100 paise)
      currency,
      receipt: receipt || `receipt_${Date.now()}`,
      notes,
    };

    const order = await razorpay.orders.create(options);

    // Store order for verification later
    orders[order.id] = {
      amount: order.amount,
      currency: order.currency,
      status: "created",
      createdAt: new Date(),
    };

    console.log("✅ Order created:", order.id);

    res.json({
      success: true,
      order_id: order.id,
      amount: order.amount,
      currency: order.currency,
      key_id: process.env.RAZORPAY_KEY_ID, // sent to frontend to init Razorpay
    });
  } catch (error) {
    console.error("❌ Create order error:", error);
    res.status(500).json({ error: "Failed to create order", details: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
//  ROUTE 2: Verify Payment
//  After user pays, Razorpay sends back 3 fields.
//  We verify the signature using HMAC-SHA256 to confirm
//  the payment is genuine (not tampered).
// ─────────────────────────────────────────────────────────────
app.post("/api/verify-payment", (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return res.status(400).json({ error: "Missing payment details" });
    }

    // Step 1: Recreate the expected signature
    const body = razorpay_order_id + "|" + razorpay_payment_id;
    const expectedSignature = crypto
      .createHmac("sha256", process.env.RAZORPAY_KEY_SECRET)
      .update(body)
      .digest("hex");

    // Step 2: Compare with the signature Razorpay sent
    const isAuthentic = expectedSignature === razorpay_signature;

    if (isAuthentic) {
      // Update order status in our store
      if (orders[razorpay_order_id]) {
        orders[razorpay_order_id].status = "paid";
        orders[razorpay_order_id].paymentId = razorpay_payment_id;
        orders[razorpay_order_id].paidAt = new Date();
      }

      console.log("✅ Payment verified:", razorpay_payment_id);

      // TODO: Update your database, send confirmation email, fulfill order etc.

      res.json({
        success: true,
        message: "Payment verified successfully",
        payment_id: razorpay_payment_id,
        order_id: razorpay_order_id,
      });
    } else {
      console.warn("⚠️ Signature mismatch for order:", razorpay_order_id);
      res.status(400).json({ success: false, error: "Payment verification failed. Invalid signature." });
    }
  } catch (error) {
    console.error("❌ Verify payment error:", error);
    res.status(500).json({ error: "Verification failed", details: error.message });
  }
});

// ─────────────────────────────────────────────────────────────
//  ROUTE 3: Razorpay Webhook (server-to-server)
//  Razorpay calls this URL directly for reliable event delivery.
//  Set this URL in: Razorpay Dashboard → Settings → Webhooks
//  Use your public URL e.g. https://yourdomain.com/api/webhook
// ─────────────────────────────────────────────────────────────
app.post("/api/webhook", express.raw({ type: "application/json" }), (req, res) => {
  try {
    const webhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET;
    const signature = req.headers["x-razorpay-signature"];

    if (webhookSecret) {
      // Verify webhook signature
      const expectedSig = crypto
        .createHmac("sha256", webhookSecret)
        .update(req.body)
        .digest("hex");

      if (signature !== expectedSig) {
        console.warn("⚠️ Invalid webhook signature");
        return res.status(400).json({ error: "Invalid signature" });
      }
    }

    const event = JSON.parse(req.body);
    console.log("📩 Webhook event:", event.event);

    // Handle different Razorpay events
    switch (event.event) {
      case "payment.captured":
        // Payment was captured (auto or manual)
        const payment = event.payload.payment.entity;
        console.log("💰 Payment captured:", payment.id, "Amount:", payment.amount / 100, payment.currency);
        // TODO: Fulfill order, send email, update DB
        break;

      case "payment.failed":
        const failedPayment = event.payload.payment.entity;
        console.log("❌ Payment failed:", failedPayment.id, "Reason:", failedPayment.error_description);
        // TODO: Notify customer, retry logic
        break;

      case "order.paid":
        const paidOrder = event.payload.order.entity;
        console.log("✅ Order paid:", paidOrder.id);
        break;

      case "refund.created":
        const refund = event.payload.refund.entity;
        console.log("↩️ Refund created:", refund.id, "Amount:", refund.amount / 100);
        break;

      default:
        console.log("ℹ️ Unhandled event:", event.event);
    }

    res.json({ received: true });
  } catch (error) {
    console.error("❌ Webhook error:", error);
    res.status(500).json({ error: "Webhook processing failed" });
  }
});

// ── Health check ───────────────────────────────────────────────
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    razorpay_configured: !!(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
    timestamp: new Date().toISOString(),
  });
});

// ── Start server ───────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 Server running at http://localhost:${PORT}`);
  console.log(`🔑 Razorpay Key ID: ${process.env.RAZORPAY_KEY_ID || "NOT SET ⚠️"}`);
  console.log(`📋 Checkout page:  http://localhost:${PORT}\n`);
});
